# Proyecto final para del curso "Mapeo/Objeto Relacional" en la UACM San Lorenzo Tezonco.


## Instrucciones

Los requerimientos a detalle del proyecto, están en el siguiente documento:
https://docs.google.com/document/d/1lbkjBXuvGpph-0SJtN3l6SreJOMngRZcalL2vvAl_GU/edit?usp=sharing

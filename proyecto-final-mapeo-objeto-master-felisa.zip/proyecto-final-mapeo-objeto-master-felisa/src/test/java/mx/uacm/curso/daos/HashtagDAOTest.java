/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.uacm.curso.daos;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import mx.uacm.curso.daos.impl.HashtagDAOImpl;
import mx.uacm.curso.dtos.ConteoHashtagDTO;
import mx.uacm.curso.entidades.Hashtag;
import mx.uacm.curso.entidades.Usuario;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class HashtagDAOTest {

    private static EntityManager em;

    private static HashtagDAO hashtagDAO;

    @AfterAll
    //ejecuta antes de todos los tests
    public static void antes() {
        System.out.println("iniciando tests");
    }

    @AfterAll
    //ejecuta despues de todos los tests
    public static void terminar() {
        System.out.println("tests terminados");
    }

    @BeforeAll
    public static void inicializar() throws Exception {
        System.out.println("inicializando..");
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("base-proyecto-memoria");
        em = emf.createEntityManager();
        hashtagDAO = new HashtagDAOImpl(em);
        System.out.println("inicializado");
    }

    @BeforeEach
    public void antesDeCadaTest() {
        System.out.println("antes del test");
        em.getTransaction().begin(); //iniciamos transaccion
    }

    @AfterEach
    public void despuesDeCadaTest() {
        em.flush();
        System.out.println("despues del test");
        em.getTransaction().rollback();
    }

    @Test
    @Order(1)
    public void buscarPorIdTest() throws Exception {
        Hashtag h = hashtagDAO.buscarPorId(2);
        Assertions.assertNotNull(h);
        
        assertNotNull(h.getTweets());
        assertEquals(5,h.getTweets().size());
        
    }
    
    @Test
    @Order(2)
    public void obtenerTodosTest(){
        List<String> hashtags = hashtagDAO.nombresHashtags();
        assertEquals(48,hashtags.size());
    }
    //parte Definicion DAOS No.1
    @Test
    @Order(3)
    public void nombresHashtagsTest(){
        List<String> nombres=hashtagDAO.nombresHashtags();
        System.out.println("Nombres de Hashtag :" +nombres);
        assertNotNull(nombres);
        assertEquals(48, nombres.size());
    
    
    }
    //parte Definicion DAOS No. 2
    @Test
    @Order(4)
    public void conteoHashtagsTest(){
            List<ConteoHashtagDTO> total=hashtagDAO.conteoHashtags();
            System.out.println("La lista de Hashtag es  :"+ total);
            assertNotNull(total);
            assertEquals(48,total.size());
            
    
    }
    //parte Definicion DAOS No. 3
    @Test
    @Order(5)
    public void conteoHashtags(){
         List<ConteoHashtagDTO> has=hashtagDAO.conteoHashtags("git");
         System.out.println("has :" +has);
         assertNotNull(has);
         assertEquals(3,has.size());
         
    
    }
    
    
    
   

}

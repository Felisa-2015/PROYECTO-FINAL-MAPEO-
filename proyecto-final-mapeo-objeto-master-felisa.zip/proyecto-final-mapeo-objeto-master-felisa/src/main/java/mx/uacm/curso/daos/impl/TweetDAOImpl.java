/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.uacm.curso.daos.impl;

import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import mx.uacm.curso.daos.TweetDAO;
import mx.uacm.curso.dtos.ConteoHashtagDTO;
import mx.uacm.curso.entidades.Pais;

import mx.uacm.curso.entidades.Tweet;

public class TweetDAOImpl extends GenericDAOImpl<Tweet, Integer> implements TweetDAO {

    public TweetDAOImpl(EntityManager em) {
        super(em);
    }
    //parte Definicion DAOS No. 1
    @Override
    public List<Tweet> tweetsPorHashtags(List<String> nombresHashtags) {
        TypedQuery<Tweet> consulta=em.createQuery("SELECT t FROM Tweet  t INNER JOIN t.hashtag c WHERE c.nombre IN :patron\n" ,Tweet.class);
         consulta.setParameter("patron",nombresHashtags);
        List<Tweet> tweets=consulta.getResultList();
        return tweets;
        
    }
    //parte Definicion DAOS No. 2
    @Override
    public List<Integer> tweetsIdsPorHashtagsYFecha(List<String> nombresHashtags, Date fechaMin, Date fechaMax) {
        TypedQuery<Integer> consulta= em.createQuery("SELECT distinct(t.id) FROM Tweet t INNER JOIN t.hashtag  h WHERE h.nombre IN :patron AND t.fecha BETWEEN :fechaMin AND :fechaMax ",Integer.class);
        consulta.setParameter("patron", nombresHashtags);
        consulta.setParameter("fechaMin", fechaMin);
        consulta.setParameter("fechaMax", fechaMax);
        List<Integer> resultado = consulta.getResultList();
        return resultado;
    }
    //parte Definicion DAOS No. 3
    @Override
    public List<Integer> filtrarTweetsIdsPorPais(List<Integer> tweetsIds, Pais pais) {
        TypedQuery<Integer> consulta= em.createQuery(" SELECT t.id FROM Lugar l INNER JOIN l.pais p INNER JOIN l.tweet t WHERE t.id IN :patron AND p.id=:idPais ",Integer.class);
        consulta.setParameter("patron", tweetsIds);
        consulta.setParameter("idPais", pais.getId());
        List<Integer> resultado = consulta.getResultList();
        return resultado;
        
    }
    
    

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.uacm.curso.daos.impl;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import mx.uacm.curso.daos.EmocionDAO;
import mx.uacm.curso.dtos.ConteoHashtagDTO;
import mx.uacm.curso.dtos.EmocionPredominanteDTO;
import mx.uacm.curso.entidades.Emocion;

public class EmocionDAOImpl extends GenericDAOImpl<Emocion, Integer> implements EmocionDAO {

    public EmocionDAOImpl(EntityManager em) {
        super(em);
    }
    //parte Definicion DAOS No. 1
    @Override
    public EmocionPredominanteDTO emocionPredominantePorTweetsIds(List<Integer> tweetsIds) {
       int j=0;
        Query consulta=em.createQuery("SELECT avg(e.felicidad),avg(e.tristeza),avg(e.enojo),avg(e.miedo),avg(e.animado),avg(e.indiferente) FROM Tweet t INNER JOIN t.emocion e WHERE t.id IN :patron");
        consulta.setParameter("patron", tweetsIds);
        Object[] resultado =(Object []) consulta.getSingleResult();
        double max=(double)resultado[0] ;
        for (int i=0; i<resultado.length; i++){
            if((double)resultado[i]>max){
                max=(double) resultado[i];
                j=i;
            }
            
        }
        String emocion;
        switch(j){
            case 0: emocion="felicidad";
            break;
            case 1: emocion="tristeza";
            break;
            case 2: emocion="enojo";
            break;
            case 3: emocion="miedo";
            break;
            case 4:emocion ="animado";
            break;
            case 5: emocion ="indiferente";
            break;
            default:emocion="no hay emocion";
            break;
        }
        EmocionPredominanteDTO emo=new EmocionPredominanteDTO(emocion,max);
         return emo;
        
    }
    
}

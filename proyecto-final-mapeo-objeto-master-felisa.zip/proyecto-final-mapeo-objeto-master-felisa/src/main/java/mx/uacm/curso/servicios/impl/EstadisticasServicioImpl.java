/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.uacm.curso.servicios.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import mx.uacm.curso.daos.EmocionDAO;
import mx.uacm.curso.daos.PaisDAO;
import mx.uacm.curso.daos.TweetDAO;
import mx.uacm.curso.daos.impl.GenericDAOImpl;
import mx.uacm.curso.dtos.ConteoHashtagDTO;
import mx.uacm.curso.dtos.EmocionPredominanteDTO;
import mx.uacm.curso.dtos.PaisYEmocionPredominanteDTO;
import mx.uacm.curso.entidades.Hashtag;
import mx.uacm.curso.entidades.Pais;
import mx.uacm.curso.entidades.Tweet;
import mx.uacm.curso.servicios.EstadisticasServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;



public class EstadisticasServicioImpl  implements EstadisticasServicio {

    
    private TweetDAO tweetDAO;
    
    
    private EmocionDAO emocionDAO;
    
    
    private PaisDAO paisDAO;

    public PaisDAO getPaisDAO() {
        return paisDAO;
    }

    public void setPaisDAO(PaisDAO paisDAO) {
        this.paisDAO = paisDAO;
    }
    
    
    public TweetDAO getTweetDAO() {
        return tweetDAO;
    }

    public void setTweetDAO(TweetDAO tweetDAO) {
        this.tweetDAO = tweetDAO;
    }

    public EmocionDAO getEmocionDAO() {
        return emocionDAO;
    }

    public void setEmocionDAO(EmocionDAO emocionDAO) {
        this.emocionDAO = emocionDAO;
    }
    //parte servicios
    @Override
   public List<PaisYEmocionPredominanteDTO> emocionesPredominantesAgrupadasPorPais(List<String> hashtags, Date fechaMin, Date fechaMax) {
         List<PaisYEmocionPredominanteDTO> paisesYEmociones=new ArrayList();
         List<Integer> tweets= tweetDAO.tweetsIdsPorHashtagsYFecha(hashtags, fechaMin, fechaMax);
         List<Pais> paises=paisDAO.obtenPorTweetsIds(tweets);
         List<Integer> tweetsIdsPorPaises=new ArrayList<>();
         for(int i=0;i<paises.size();i++){
             tweetsIdsPorPaises=tweetDAO.filtrarTweetsIdsPorPais(tweets, paises.get(i));
             EmocionPredominanteDTO emo=emocionDAO.emocionPredominantePorTweetsIds(tweetsIdsPorPaises);
             PaisYEmocionPredominanteDTO paisYEmocion = new PaisYEmocionPredominanteDTO(paises.get(i), emo);
             paisesYEmociones.add(paisYEmocion);
                        
         }
         System.out.println("Metodo emocionesPredominantesAgrupadasPorPais");
         
         return paisesYEmociones;
        
    }

}

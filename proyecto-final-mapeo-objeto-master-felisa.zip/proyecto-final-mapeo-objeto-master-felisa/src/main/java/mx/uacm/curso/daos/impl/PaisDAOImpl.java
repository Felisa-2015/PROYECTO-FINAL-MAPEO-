/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.uacm.curso.daos.impl;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import mx.uacm.curso.daos.PaisDAO;
import mx.uacm.curso.dtos.ConteoHashtagDTO;
import mx.uacm.curso.entidades.Pais;

public class PaisDAOImpl extends GenericDAOImpl<Pais, Integer> implements PaisDAO {

    public PaisDAOImpl(EntityManager em) {
        super(em);
    }
    //parte Definicion DAOS No. 1
    @Override
    public List<Pais> obtenPorTweetsIds(List<Integer> tweetsIds) {
        TypedQuery<Pais> consulta=em.createQuery("SELECT  p FROM Lugar l INNER JOIN l.pais p INNER JOIN l.tweet t WHERE t.id IN :patron GROUP BY p",Pais.class);
        consulta.setParameter("patron",tweetsIds);
        List<Pais> paises=consulta.getResultList();
        return paises;
        
    
    
    }

}
